#!/usr/bin/python
# -*- coding: UTF-8 -*-
'''
Created on 2022-10-14

Author: Chao Zhang

Description:
            a. Modified the assignment statement to include preliminary screening after crossover and mutation,
            and called the new_evolve function from the operators_res script.
            children = self.variator.new_evolve(parents)
            b. Added a new function step_advanced.
            Unlike the preliminary screening after crossover and mutation during the iteration process, 
            this function is used to pre-screen better solutions from the initial population.

'''
# Copyright 2012-2014 The Pennsylvania State University
# Copyright 2020 Cornell University
#
# This software was written by Andrew Dircks, Dave Hadka, and others.
#
# The use, modification and distribution of this software is governed by the
# The Pennsylvania State University Research and Educational Use License.
# You should have received a copy of this license along with this program.
# If not, contact <info@borgmoea.org>.

from __future__ import absolute_import, division, print_function

import random
import datetime
from collections import deque
from operators_res import TournamentSelector, Multimethod,\
    GAOperator, SBX, PM, UM, PCX, UNDX, SPX, DifferentialEvolution
from algorithms_res import EpsilonProgressContinuation, EpsMOEA, RandomGenerator
from init_evaluation import init_evaluation_fun


class BorgMOEA(EpsilonProgressContinuation):

    def __init__(self, problem,
                 epsilons,
                 population_size=100,
                 generator=RandomGenerator(),
                 selector=TournamentSelector(2),
                 recency_list_size=50,
                 max_mutation_index=10,
                 selection_ratio=0.02,
                 **kwargs):
        super(BorgMOEA, self).__init__(
            EpsMOEA(problem,
                    epsilons,
                    population_size,
                    generator,
                    selector,
                    **kwargs))
        self.recency_list = deque()
        self.recency_list_size = recency_list_size
        self.restarted_last_check = False
        self.base_mutation_index = 0
        self.max_mutation_index = max_mutation_index
        self.selection_ratio = selection_ratio
        self.svm_nfe = 0

        # overload the variator and iterate method
        self.algorithm.variator = Multimethod(self, [
            GAOperator(SBX(), PM()),
            GAOperator(DifferentialEvolution(), PM()),
            UM(),
            PCX(),
            UNDX(),
            SPX()])

        self.algorithm.iterate = self.iterate

    def do_action(self):

        f = open("RestartRecord.log", "a+")
        time_format = '%Y-%m-%d  %H:%M:%S'
        now = datetime.datetime.now()
        f.write("\n")
        f.write("\n Check Time = " + now.strftime(time_format))
        f.write("\n Current Iteration = " + str(self.iteration))
        f.write("\n Current NumofEvaluation = " + str(self.iteration))
        f.write("\n SizeofPops = " + str(len(self.algorithm.population)))
        f.write("\n SizeofArcs = " + str(len(self.algorithm.archive)))
        f.flush()

        if self.check():

            f.write("\n Restart is triggered !!!")
            f.flush()

            if self.restarted_last_check:
                self.base_mutation_index = min(self.base_mutation_index+1,
                                               self.max_mutation_index)

            # update the mutation probability prior to restart
            probability = self.base_mutation_index / \
                float(self.max_mutation_index)
            probability = probability + \
                (1.0 - probability)/self.algorithm.problem.nvars
            self.mutator.probability = probability

            self.restart(f)

            # adjust selection pressure
            tournament_size = max(
                2, int(self.selection_ratio * len(self.population)))
            self.selector = TournamentSelector(tournament_size)
            self.restarted_last_check = True

            f.close()

        else:

            f.write("\n Restart is not triggered !!!")
            f.flush()

            if self.restarted_last_check:
                self.base_mutation_index = max(self.base_mutation_index-1, 0)
            self.restarted_last_check = False

            f.close()

    def iterate(self):

        if len(self.archive) <= 1:
            parents = self.selector.select(
                self.variator.arity, self.population)
        else:
            parents = self.selector.select(
                self.variator.arity-1, self.population) + [random.choice(self.archive)]

        random.shuffle(parents)

        # children = self.variator.evolve(parents)
        # children = self.variator.new_evolve(parents)
        variator = self.variator.variators[self.variator.next_variator]
        result = []
        better_results = []
        while len(better_results) <= len(result):
            result = variator.evolve(parents)
            for num, solution in enumerate(result):
                solution = init_evaluation_fun(solution)
                self.tot_nfe += 1
                if not solution.init_constraint_violation:
                    better_results.append(solution)
        children = random.sample(better_results, len(result))
        for solution in children:
            solution.operator = self.variator.next_variator

        self.variator.select()
        self.algorithm.evaluate_all(children)
        self.swat_nfe += len(children)
        self.nfe = self.algorithm.nfe

        for child in children:
            self._add_to_population(child)

            if self.archive.add(child):
                self.recency_list.append(child)

                if len(self.recency_list) > self.recency_list_size:
                    self.recency_list.popleft()


    def step_advanced(self):

        if self.algorithm.nfe == 0:
            unevaluated = []
            while len(unevaluated) <= self.population_size:
                sol = self.generator.generate(self.algorithm.problem)
                solution = init_evaluation_fun(sol)
                self.tot_nfe += 1
                if not solution.init_constraint_violation:
                    unevaluated.append(solution)

            self.algorithm.population = unevaluated
            self.algorithm.evaluate_all(self.algorithm.population)
            self.swat_nfe += len(self.algorithm.population)
            self.algorithm.archive += self.algorithm.population

        else:
            self.algorithm.iterate()

        self.algorithm.result = self.algorithm.archive
