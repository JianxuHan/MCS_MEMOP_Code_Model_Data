from __future__ import absolute_import, division, print_function
#!/usr/bin/python
# -*- coding: UTF-8 -*-
"""
Created on 2022-10-14

@author: Chao Zhang & Jianxu Han

Description:

           The following files need to be prepared in the same directory as this script:
            a. SWAT model folder (name can be modified in this script): contains only folders for multiple climate scenarios (folder naming format can be modified in this script).
            b. init_evaluation script: used to pre-screen poor solutions (based on cost and surrogate model).
            c. Three Borg-related scripts (suitable for parallel computing, no modification needed):

            borg_res.py

            operators_res.py

            algorithms_res.py

            This script automatically generates an mpi_swat folder, inside which multi-threaded folders are created. In each folder, it automatically copies the multiple climate scenario folders from the SWAT folder.

            The script also generates a folder named Iteration_Results to store intermediate iterative optimization solutions:
            a. "RunningTime.txt" — records of iterations
            b. 'SwatIteration_'+ str(last_log) +'.txt' — SWAT model results
"""

import time
import math
import numpy as np
import xlrd
import sys
import os
import shutil
from platypus.core import Problem
from platypus.types import Real

from platypus.mpipool import MPIPool
from platypus import PoolEvaluator
from borg_res import BorgMOEA
import datetime
from operators_res import Multimethod, GAOperator, SBX, PM, UM, PCX, UNDX, \
    SPX, DifferentialEvolution

from matplotlib import pyplot as plt
from mpl_toolkits import mplot3d

totstart_time = time.time()

initial_population_size = 200  
maxevals = 20000  
frequency = 1000 
epsilonsets = 0.01  
nobjs = 3  
nvars = 17  
nconstrs = 15  
num_meteors = 1 
swatdata_fname = "swatdata"  
xiqiang_fname_format = "future_scenario_"  
swatdata_mpifname = "mpi_swatdata"  
swatdata_mpifname_format = "mpi_pro_"  
limit_cost_epoch = 25  
limit_tn = [83.59, 75.23, 67.71, 60.94, 54.84]  
limit_tp = [17.96, 16.17, 14.55, 13.10, 11.79]  

mainpath = os.getcwd()
bordernpar = 0.4126
borderppar = 0.0958
factorynpar = 0.4126
NH3CNST_feedp_Factor = 0.008
ORGNCNST_feedp_Factor = 0.012
ORGPCNST_feedp_Factor = 0.0005
MINPCNST_feedp_Factor = 0.0005
paragrl1n_factor = 0.5
paragrl1p_factor = 0.3
ruralnpar = 0.0
ruralppar = 0.0
animalindexn1par = 0.9691
animalindexn2par = 0.0309
animalindexn3par = 0.0
animalindexp1par = 0.9691
animalindexp2par = 0.0309
animalindexp3par = 0.0

def insertionSort(arr):

    for i in range(len(arr)):
        preIndex = i - 1
        current = arr[i]
        while preIndex >= 0 and arr[preIndex] > current:
            arr[preIndex + 1] = arr[preIndex]
            preIndex -= 1
        arr[preIndex + 1] = current
    return arr

def GetFileList(path, fileList):

    for root, dirs, files in os.walk(path):
        for i in files:
            fileList.append(i)
    return fileList


class SwatInterVention17Objs(Problem): 

    def __init__(self, nobjs=3, nvars=17, nconstrs=15):
        # def __init__(self, nobjs=11, nvars=13, nconstrs=10):
        super(SwatInterVention17Objs, self).__init__(nvars, nobjs, nconstrs)
        # self.directions[0] = "MINIMIZE"
        # self.directions[0:3] = ["MINIMIZE","MINIMIZE","MINIMIZE"]
        self.types[0:7] = Real(0, 5.99999999)
        self.types[7:] = Real(0, 1.9999999)
        self.constraints[:] = ">=0"

    def evaluate(self, solution):

        border = math.floor(solution.variables[0])
        factory = math.floor(solution.variables[1])
        feedp = math.floor(solution.variables[2])
        animal = math.floor(solution.variables[3])
        terracing = math.floor(solution.variables[4])
        filterstrip = math.floor(solution.variables[5])
        waterway = math.floor(solution.variables[6])
        agrla = math.floor(solution.variables[7])
        agrlb = math.floor(solution.variables[8])
        agrlc = math.floor(solution.variables[9])
        agrld = math.floor(solution.variables[10])
        agrle = math.floor(solution.variables[11])
        rurala = math.floor(solution.variables[12])
        ruralb = math.floor(solution.variables[13])
        ruralc = math.floor(solution.variables[14])
        rurald = math.floor(solution.variables[15])
        rurale = math.floor(solution.variables[16])

        totscetnps = []
        for scenarioid in range(num_meteors):
            to_path = os.path.join(mainpath, swatdata_mpifname,
                                   swatdata_mpifname_format+str(pool.rank),
                                   xiqiang_fname_format+str(scenarioid+1))
            os.chdir(to_path)
            optipar_path = to_path + '\\' + u'parameters' + '\\'
            pointsourcefp = optipar_path + 'pointsource\\dat.xlsx'
            psdatfilename = ['2p.dat',  '6p.dat',  '8p.dat',  '11p.dat',
                             '15p.dat', '16p.dat', '18p.dat', '20p.dat',
                             '23p.dat', '26p.dat', '28p.dat', '35p.dat']
            psininterpath = optipar_path + 'pointsource\\no-measure\\'
            psoutinterpath = optipar_path + 'pointsource\\after-measure\\'
            psyesinter_path = optipar_path + 'pointsource\\after-measure'
            fertnfileinname = optipar_path + 'fert\\no-measure\\parn.txt'
            fertnfileoutname = optipar_path + 'fert\\after-measure\\parn.txt'
            fertpfileinname = optipar_path + 'fert\\no-measure\\parp.txt'
            fertpfileoutname = optipar_path + 'fert\\after-measure\\parp.txt'
            fertyesinter_path = optipar_path + 'fert\\after-measure'

            opsinterinpath = optipar_path + 'ops\\no-measure'
            opsinterinname = optipar_path + 'ops\\no-measure\\'
            opsinteroutname = optipar_path + 'ops\\after-measure\\'
            opssubfile_path1 = optipar_path + 'sub\\no-measure'
            opssubfile_path2 = optipar_path + 'sub\\after-measure'
            opshrufile_path = optipar_path + 'hru'
            opshrufilename = optipar_path + 'hru\\'
            opsfile_path = optipar_path + 'ops\\after-measureops'

            mainexepath = to_path + '\\' + 'codelimcon.exe'

            outputfilepath = to_path + '\\' + 'output.rch'

            year_border = 2021 + border * 5 
            month_border = (year_border - 1991) * 12
            parbordern = np.ones(660)
            parborderp = np.ones(660)
            parbordern[month_border:] = bordernpar
            parborderp[month_border:] = borderppar
            year_factory = 2021 + factory * 5
            month_factory = (year_factory - 1991) * 12
            parfactoryn = np.ones(660)
            parfactoryn[month_factory:] = factorynpar
            year_feed = 2021 + feedp * 5
            month_feed = (year_feed - 1991) * 12
            worksheet = xlrd.open_workbook(pointsourcefp)
            sheet_names = worksheet.sheet_names()  
            for sh in range(0, 12): 
                sheet = worksheet.sheet_by_name(sheet_names[sh])
                FLOCNST_border = np.array(sheet.col_values(2, 1))
                ORGNCNST_border = np.array(sheet.col_values(3, 1))
                ORGPCNST_border = np.array(sheet.col_values(4, 1))
                NO3CNST_border = np.array(sheet.col_values(5, 1))
                NH3CNST_border = np.array(sheet.col_values(6, 1))
                NO2CNST_border = np.array(sheet.col_values(7, 1))
                MINPCNST_border = np.array(sheet.col_values(8, 1))
                FLOCNST_feedp = np.array(sheet.col_values(9, 1))
                ORGNCNST_feedp = np.array(sheet.col_values(10, 1))
                ORGPCNST_feedp = np.array(sheet.col_values(11, 1))
                NO3CNST_feedp = np.array(sheet.col_values(12, 1))
                NH3CNST_feedp = np.array(sheet.col_values(13, 1))
                NO2CNST_feedp = np.array(sheet.col_values(14, 1))
                MINPCNST_feedp = np.array(sheet.col_values(15, 1))
                FLOCNST_factory = np.array(sheet.col_values(16, 1))
                ORGNCNST_factory = np.array(sheet.col_values(17, 1))
                ORGPCNST_factory = np.array(sheet.col_values(18, 1))
                NO3CNST_factory = np.array(sheet.col_values(19, 1))
                NH3CNST_factory = np.array(sheet.col_values(20, 1))
                NO2CNST_factory = np.array(sheet.col_values(21, 1))
                MINPCNST_factory = np.array(sheet.col_values(22, 1))
                ORGNCNST_bordera = ORGNCNST_border * parbordern
                ORGPCNST_bordera = ORGPCNST_border * parborderp
                NO3CNST_bordera = NO3CNST_border * parbordern
                NH3CNST_bordera = NH3CNST_border * parbordern
                NO2CNST_bordera = NO2CNST_border * parbordern
                MINPCNST_bordera = MINPCNST_border * parborderp
                NH3CNST_factorya = NH3CNST_factory * parfactoryn
                NH3CNST_feedp[month_feed:] = np.array(
                    FLOCNST_feedp[
                        month_feed:]) * NH3CNST_feedp_Factor
                ORGNCNST_feedp[month_feed:] = np.array(
                    FLOCNST_feedp[
                        month_feed:]) * ORGNCNST_feedp_Factor
                ORGPCNST_feedp[month_feed:] = np.array(
                    FLOCNST_feedp[
                        month_feed:]) * ORGPCNST_feedp_Factor
                MINPCNST_feedp[month_feed:] = np.array(
                    FLOCNST_feedp[
                        month_feed:]) * MINPCNST_feedp_Factor
                FLOCNST = FLOCNST_border + FLOCNST_feedp + FLOCNST_factory
                ORGNCNST = ORGNCNST_bordera + ORGNCNST_feedp + ORGNCNST_factory
                ORGPCNST = ORGPCNST_bordera + ORGPCNST_feedp + ORGPCNST_factory
                NO3CNST = NO3CNST_bordera + NO3CNST_feedp + NO3CNST_factory
                NH3CNST = NH3CNST_bordera + NH3CNST_feedp + NH3CNST_factorya
                NO2CNST = NO2CNST_bordera + NO2CNST_feedp + NO2CNST_factory
                MINPCNST = MINPCNST_bordera + MINPCNST_feedp + MINPCNST_factory
                datnew = np.c_[FLOCNST, ORGNCNST, ORGPCNST, NO3CNST,
                               NH3CNST, NO2CNST, MINPCNST]
                datfilein = open(psininterpath + psdatfilename[sh], 'r')
                datfileout = open(psoutinterpath + psdatfilename[sh], 'w')
                Field = ["FLOCNST", "ORGNCNST", "ORGPCNST", "NO3CNST",
                         "NH3CNST", "NO2CNST", "MINPCNST"]
                fieldlist = []
                for i in range(5):
                    line = str(datfilein.readline())
                    datfileout.write(line)
                line = str(datfilein.readline())
                for filedname in Field:
                    fieldlist.append(line.split().index(filedname))
                datfileout.write(line)
                for datrow in range(660):
                    line = datfilein.readline()
                    linelist = line.split()
                    for i in range(len(Field)):
                        wordvalue = '{:.10E}'.format(datnew[datrow][i])
                        linelist[fieldlist[i]] = wordvalue
                        ' '.join(linelist) 
                    if float(linelist[0]) < 10: 
                        datfileout.write('     ') 
                    else: 
                        datfileout.write('    ')
                    datfileout.write(' '.join(linelist))
                    datfileout.write('\n')
                datfilein.close()
                datfileout.close()
            dirs = os.listdir(psyesinter_path)  
            for i in dirs:
                from_path = os.path.join(psyesinter_path, i)
                shutil.copy(from_path, to_path)

            agrl0 = 0
            aa = np.ones(5)
            bb = np.ones(30)
            paragrl0 = bb * agrl0
            paragrla = agrla * aa
            paragrlb = agrlb * aa
            paragrlc = agrlc * aa
            paragrld = agrld * aa
            paragrle = agrle * aa
            paragrln = np.r_[paragrl0, paragrla, paragrlb,
                             paragrlc, paragrld, paragrle]
            paragrlp = np.r_[paragrl0, paragrla, paragrlb,
                             paragrlc, paragrld, paragrle]
            paragrlindex1n = (paragrln == 1)
            paragrlindex1p = (paragrlp == 1)
            paragrlindex2n = (paragrln == 0)
            paragrlindex2p = (paragrlp == 0)
            paragrln[paragrlindex1n] = paragrl1n_factor
            paragrlp[paragrlindex1p] = paragrl1p_factor
            paragrln[paragrlindex2n] = 1
            paragrlp[paragrlindex2p] = 1

            rural0 = 0
            cc = np.ones(5)
            dd = np.ones(30)
            parrural0 = dd * rural0
            parrurala = rurala * cc
            parruralb = ruralb * cc
            parruralc = ruralc * cc
            parrurald = rurald * cc
            parrurale = rurale * cc
            parruraln = np.r_[parrural0, parrurala, parruralb,
                              parruralc, parrurald, parrurale]
            parruralp = np.r_[parrural0, parrurala, parruralb,
                              parruralc, parrurald, parrurale]
            parruralindex1n = (parruraln == 1)
            parruralindex1p = (parruralp == 1)
            parruralindex2n = (parruraln == 0)
            parruralindex2p = (parruralp == 0)
            parruraln[parruralindex1n] = ruralnpar
            parruralp[parruralindex1p] = ruralppar
            parruraln[parruralindex2n] = 1
            parruralp[parruralindex2p] = 1

            ee = np.ones(30)
            parruralx = np.r_[parrurala, parruralb, parruralc,
                              parrurald, parrurale]
            parruralindex1x = (parruralx == 1)
            parruralindex2x = (parruralx == 0)
            parruralx[parruralindex1x] = 2
            parruralx[parruralindex2x] = 0  
            par_animal1 = parruralx
            ff = np.ones(25)
            par_animal2 = ff * 0
            year_animal = animal * 5
            par_animal2[year_animal:] = 3 
            par_animalaaa = par_animal1 + par_animal2
            indexn1 = (par_animalaaa == 0)
            par_animalaaa[indexn1] = 1
            indexn1 = (par_animalaaa == 2)
            par_animalaaa[indexn1] = animalindexn1par
            indexn2 = (par_animalaaa == 3)
            par_animalaaa[indexn2] = animalindexn2par
            indexn3 = (par_animalaaa == 5)
            par_animalaaa[indexn3] = animalindexn3par
            par_animaln = np.r_[ee, par_animalaaa]
            par_animalbbb = par_animal1 + par_animal2
            par_animalp = par_animal1 + par_animal2
            indexp1 = (par_animalbbb == 0)
            par_animalbbb[indexp1] = 1
            indexp1 = (par_animalbbb == 2)
            par_animalbbb[indexp1] = animalindexp1par
            indexp2 = (par_animalbbb == 3)
            par_animalbbb[indexp2] = animalindexp2par
            indexp3 = (par_animalbbb == 5)
            par_animalbbb[indexp3] = animalindexp3par
            par_animalp = np.r_[ee, par_animalbbb]
            fertnfilein = open(fertnfileinname, 'r')
            fertnfileout = open(fertnfileoutname, 'w')
            linen0 = fertnfilein.readline()
            print(linen0, file=fertnfileout, end='') 
            fertnfieldlist = linen0.split()
            col_numbern = len(fertnfieldlist) 
            agrln_index = [] 
            urbnn_index = []
            animaln_index = []
            for i in range(col_numbern):
                if fertnfieldlist[i] == 'AGRL':
                    agrln_index.append(i) 
                elif fertnfieldlist[i] == 'URBN':
                    urbnn_index.append(i)
                elif fertnfieldlist[i] == 'ANIMAL':
                    animaln_index.append(i)
            for rown in range(len(paragrln)):
                line = fertnfilein.readline().split()
                for col in agrln_index:
                    line[col] = '{:1.4f}'.format(paragrln[rown])
                for col in urbnn_index:
                    line[col] = '{:1.4f}'.format(parruraln[rown])
                for col in animaln_index:
                    line[col] = '{:1.4f}'.format(par_animaln[rown])
                for i in line:
                    print(i, file=fertnfileout, end='  ')
                print(file=fertnfileout) 
            fertnfilein.close()
            fertnfileout.close()

            fertpfilein = open(fertpfileinname, 'r')
            fertpfileout = open(fertpfileoutname, 'w')
            linep0 = fertpfilein.readline()
            print(linen0, file=fertpfileout, end='') 
            fertpfieldlist = linep0.split()
            col_numberp = len(fertpfieldlist) 
            agrlp_index = [] 
            urbnp_index = []
            animalp_index = []
            for i in range(col_numberp):
                if fertpfieldlist[i] == 'AGRL':
                    agrlp_index.append(i) 
                elif fertpfieldlist[i] == 'URBN':
                    urbnp_index.append(i)
                elif fertpfieldlist[i] == 'ANIMAL':
                    animalp_index.append(i)
            for rowp in range(len(paragrlp)):
                line = fertpfilein.readline().split()
                for col in agrlp_index:
                    line[col] = '{:1.4f}'.format(paragrlp[rowp])
                for col in urbnp_index:
                    line[col] = '{:1.4f}'.format(parruralp[rowp])
                for col in animalp_index:
                    line[col] = '{:1.4f}'.format(par_animalp[rowp])
                for i in line:
                    print(i, file=fertpfileout, end='  ') 
                print(file=fertpfileout) 
            fertpfilein.close()
            fertpfileout.close()

            dirs = os.listdir(fertyesinter_path) 
            for i in dirs:
                from_path = os.path.join(fertyesinter_path, i)
                shutil.copy(from_path, to_path)

            stripcrop = 5
            terracing_year = 2021 + terracing * 5
            filterstrip_year = 2021 + filterstrip * 5
            stripcrop_year = 2021 + stripcrop * 5
            waterway_year = 2021 + waterway * 5
            ww = terracing + filterstrip + stripcrop + waterway
            terracing_ops = '  1  1     {0:4.0f}  1                      0.10000  74.00    15.00000'.format(terracing_year)
            filterstrip_ops = '  1  1     {0:4.0f}  4    1      40.00      0.50000  50.00'.format(filterstrip_year)
            stripcrop_ops = '  1  1     {0:4.0f}  5                      0.25000  74.00     0.13300     0.30'.format(stripcrop_year)
            waterway_ops = '  1  1     {0:4.0f}  7    1       0.25      0.01000   0.23     5.00000     0.00   0.00'.format(waterway_year)
            a = [terracing_ops, filterstrip_ops, stripcrop_ops, waterway_ops]
            b = [terracing_year, filterstrip_year, stripcrop_year, waterway_year]
            dict(zip(a, b))
            insertionSort(a)  
            insertionSort(b)
            e = [filterstrip_ops, waterway_ops]  
            f = [filterstrip_year, waterway_year]  
            dict(zip(e, f))
            insertionSort(e)
            insertionSort(f)
            b0 = b[0]
            b1 = b[1]
            b2 = b[2]
            b3 = b[3]
            if b0 < 2046:
                a0 = a[0]
            else:
                a0 = ''
            if b1 < 2046:
                a1 = a[1]
            else:
                a1 = ''
            if b2 < 2046:
                a2 = a[2]
            else:
                a2 = ''
            if b3 < 2046:
                a3 = a[3]
            else:
                a3 = ''

            f0 = f[0]
            f1 = f[1]
            if f0 < 2046:
                e0 = e[0]
            else:
                e0 = ''
            if f1 < 2046:
                e1 = e[1]
            else:
                e1 = ''
            flist = GetFileList(opsinterinpath, [])
            hruflist = GetFileList(opshrufile_path, [])
            for i, j in zip(flist, hruflist):
                r1 = open(opsinterinname + i, 'r')
                hrulogname = opshrufilename + j
                r2 = open(hrulogname, 'r')
                w = open(opsinteroutname + i, 'w')
                line0 = r1.readline()
                print(line0, file=w, end='')
                data = line0.split()
                Landuse = data[6][5:]
                row_times = 0
                for line in open(hrulogname):
                    line = r2.readline()
                    if row_times == 3:
                        Slope2 = float(line.split()[0])
                        break
                    row_times += 1
                if Landuse == 'AGRL' and Slope2 > 0.087:
                    print(a0, file=w)
                    print(a1, file=w)
                    print(a2, file=w)
                    print(a3, file=w)
                else:
                    print(e0, file=w)
                    print(e1, file=w)
                r1.close()
            if ww == 20:
                subfile_path = opssubfile_path1
            else:
                subfile_path = opssubfile_path2
                r2.close()
                w.close()
            dirs = os.listdir(subfile_path)  
            for i in dirs:
                from_path = os.path.join(subfile_path, i)
                shutil.copy(from_path, to_path)
            dirs = os.listdir(opsfile_path) 
            for i in dirs:
                from_path = os.path.join(opsfile_path, i)
                shutil.copy(from_path, to_path)

            os.system(mainexepath)

            infile = open(outputfilepath, 'r') 
            flow = []
            TNload = []
            TPload = []
            for i in range(9):
                line = str(infile.readline())
            line = str(infile.readline())
            while line:
                data1 = float(line[8:10])
                data2 = float(line[21:25])
                if data1 == 33.0 and data2 > 2020:
                    flow.append(float(line[51:61]))
                    TNload.append(float(line[543:553]))
                    TPload.append(float(line[555:565]))
                line = str(infile.readline())
            infile.close()
            TNload1 = sum(TNload[0:5])/5000
            TNload2 = sum(TNload[5:10])/5000
            TNload3 = sum(TNload[10:15])/5000
            TNload4 = sum(TNload[15:20])/5000
            TNload5 = sum(TNload[20:25])/5000
            TPload1 = sum(TPload[0:5])/5000
            TPload2 = sum(TPload[5:10])/5000
            TPload3 = sum(TPload[10:15])/5000
            TPload4 = sum(TPload[15:20])/5000
            TPload5 = sum(TPload[20:25])/5000
            if TNload1 == 0:
                TNload1 = 10000000
            if TNload2 == 0:
                TNload2 = 10000000
            if TNload3 == 0:
                TNload3 = 10000000
            if TNload4 == 0:
                TNload4 = 10000000
            if TNload5 == 0:
                TNload5 = 10000000
            if TPload1 == 0:
                TPload1 = 10000000
            if TPload2 == 0:
                TPload2 = 10000000
            if TPload3 == 0:
                TPload3 = 10000000
            if TPload4 == 0:
                TPload4 = 10000000
            if TPload5 == 0:
                TPload5 = 10000000
            totscetnps.append([TNload1, TNload2, TNload3, TNload4, TNload5,
                               TPload1, TPload2, TPload3, TPload4, TPload5])
        totscetnps = np.array(totscetnps)
        meantnps = np.mean(totscetnps, axis=0)
        TNload = np.mean(meantnps[:5])
        TPload = np.mean(meantnps[5:])
        solution.objectives[:] = [solution.cost/100, TNload, TPload]
        solution.constraints[:] = [limit_tn[0]-meantnps[0], limit_tn[1]-meantnps[1],
                                   limit_tn[2]-meantnps[2], limit_tn[3]-meantnps[3],
                                   limit_tn[4]-meantnps[4],
                                   limit_tp[0]-meantnps[5], limit_tp[1]-meantnps[6],
                                   limit_tp[2]-meantnps[7], limit_tp[3]-meantnps[8],
                                   limit_tp[4]-meantnps[9],
                                   limit_cost_epoch-solution.cost_epo[0, 0],
                                   limit_cost_epoch-solution.cost_epo[0, 1],
                                   limit_cost_epoch-solution.cost_epo[0, 2],
                                   limit_cost_epoch-solution.cost_epo[0, 3],
                                   limit_cost_epoch-solution.cost_epo[0, 4]]


def detailed_run(algorithm, maxevals, frequency):

    foldername = "Iteration_Results"
    try:os.makedirs(foldername)
    except: pass

    # open file and set up header
    wrfile = open(foldername + "\\RunningTime.txt", 'w')
    wrfile.write("Time    No.Iteration    TotalNum    SwatNum    LensofArc")
    wrfile.write("\n")
    wrfile.flush()

    start_time = time.time()
    last_log = 0

    nvars = algorithm.problem.nvars
    nobjs = algorithm.problem.nobjs
    ncons = algorithm.problem.nconstrs

    algorithm.algorithm.step = algorithm.step_advanced

    # run the algorithm/problem for specified number of function evaluations
    algorithm.nfe = 0
    algorithm.tot_nfe = 0
    algorithm.swat_nfe = 0
    while (algorithm.tot_nfe <= maxevals):
        # step the algorithm
        algorithm.step()

        # print to file if necessary
        if (algorithm.tot_nfe >= last_log + frequency):
            last_log = algorithm.tot_nfe
            a = "%s; %d; %d; %d; %d;" % \
                (datetime.timedelta(seconds=time.time()-start_time),
                 algorithm.iteration,
                 algorithm.tot_nfe,
                 algorithm.swat_nfe,
                 len(algorithm.archive[:]))

            wrfile.write(a)
            wrfile.write("\n")
            wrfile.flush()

            wfile = open(foldername + "\\SwatIteration_" + str(last_log) + ".txt", "w")
            wfile.write("Objective       Constraints      Variables       ")
            wfile.write("\n")
            arch = algorithm.archive[:]
            for s in arch:
                for i in range(algorithm.problem.nobjs):
                    wfile.write(str(s.objectives[i]) + "  ")
                for i in range(5):
                    wfile.write(str(limit_tn[i] - s.constraints[i]) + "  ")
                for i in range(5, 10):
                    wfile.write(str(limit_tp[i-5] - s.constraints[i]) + "  ")
                for i in range(10, algorithm.problem.nconstrs):
                    wfile.write(str(s.constraints[i]) + "  ")
                for i in range(algorithm.problem.nvars):
                    wfile.write(str(math.floor(s.variables[i])) + "  ")
                wfile.write("\n")
            wfile.close()

            fig = plt.figure()
            ax1 = fig.add_subplot(1, 1, 1, projection="3d")
            ax1.scatter3D([s.objectives[0] for s in arch],
                        [s.objectives[1] for s in arch],
                        [s.objectives[2] for s in arch],
                                c='#0070C0',
                                marker='o',
                                edgecolor='k')
            ax1.grid(True)
            plt.savefig(foldername + "\\SwatIteration_" + str(last_log) + ".png", dpi=300)
            plt.close()

    # close the runtime file
    wrfile.close()


if __name__ == "__main__":

    problem = SwatInterVention17Objs(nobjs, nvars, nconstrs)

    pool = MPIPool()

    sbx_parents = pool.size*4
    de_parents = pool.size*8
    pcx_parents = pool.size*4
    spx_parents = pool.size*4
    undx_parents = pool.size*4
    um_parents = pool.size*4

    pm_probability = 0.5
    pm_distributionIndex = 20
    sbx_probability = 1
    sbx_distributionIndex = 15
    de_crossoverRate = 0.1
    de_stepSize = 0.5
    pcx_eta = 0.1
    pcx_zeta = 0.1
    spx_epsilon = 3
    undx_zeta = 0.5
    undx_eta = 0.35
    um_probability = 0.5

    PM = PM(pm_probability, pm_distributionIndex)
    SBX = SBX(sbx_parents, sbx_probability, sbx_distributionIndex)
    DE = DifferentialEvolution(de_parents, de_crossoverRate, de_stepSize)
    PCX = PCX(pcx_parents, pcx_eta, pcx_zeta)
    SPX = SPX(spx_parents, spx_epsilon)
    UNDX = UNDX(undx_parents, undx_zeta, undx_eta)
    UM = UM(um_probability)
    UM.arity = um_parents

    if not pool.is_master():
        pool.wait()
        sys.exit(0)
    else:
        curpath = os.getcwd()
        targetPath = curpath + os.path.sep + swatdata_mpifname
        try:
            os.makedirs(targetPath)
        except:
            pass
        swat_src_path = curpath + os.path.sep + swatdata_fname
        for num in range(1, pool.size+1):
            os.chdir(targetPath)
            targetname = swatdata_mpifname_format + str(num)
            curpath = os.getcwd()
            copytargetPath = curpath + os.path.sep + targetname
            if not os.path.exists(copytargetPath):
                shutil.copytree(swat_src_path, copytargetPath)
            else:
                shutil.rmtree(copytargetPath)
                shutil.copytree(swat_src_path, copytargetPath)

    # instantiate the optimization algorithm to run in parallel
    with PoolEvaluator(pool) as evaluator:
        algorithm = BorgMOEA(problem,
                             epsilons=epsilonsets,
                             population_size=initial_population_size,
                             evaluator=evaluator)

        # define a Multimethod variator and set to Borg algorithm
        custom_variator = Multimethod(algorithm, [
            GAOperator(SBX, PM),
            GAOperator(DE, PM),
            PCX,
            SPX,
            UNDX,
            UM])
        algorithm.variator = custom_variator

        # run the algorithm with the custom runner
        detailed_run(algorithm, maxevals, frequency)

    pool.close()

    os.chdir(mainpath)

    wfile = open("Approximate Pareto front of Swat.txt", "w")
    wfile.write("Objective     Constraints      Variables      ")
    wfile.write("\n")
    arch = algorithm.archive[:]
    for s in arch:
        for i in range(algorithm.problem.nobjs):
            wfile.write(str(s.objectives[i]) + "  ")
        for i in range(5):
            wfile.write(str(limit_tn[i] - s.constraints[i]) + "  ")
        for i in range(5, 10):
            wfile.write(str(limit_tp[i-5] - s.constraints[i]) + "  ")
        for i in range(10, algorithm.problem.nconstrs):
            wfile.write(str(s.constraints[i]) + "  ")
        for i in range(algorithm.problem.nvars):
            wfile.write(str(math.floor(s.variables[i])) + "  ")
        wfile.write("\n")
    wfile.close()

    fig = plt.figure()
    ax1 = fig.add_subplot(1, 1, 1, projection="3d")
    ax1.scatter3D([s.objectives[0] for s in arch],
                  [s.objectives[1] for s in arch],
                  [s.objectives[2] for s in arch],
                    c='#0070C0',
                    marker='o',
                    edgecolor = 'k')
    ax1.grid(True)
    plt.savefig("Approximate Pareto front of Swat.png", dpi=300)
    plt.close()
