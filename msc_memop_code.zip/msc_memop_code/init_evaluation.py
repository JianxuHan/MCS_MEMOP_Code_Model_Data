# -*- coding: utf-8 -*-
"""
Created on 2022-10-14

@author: Chao Zhang

Description:
"""

import numpy as np
import math



"""常规设置"""
limit_cost_epoch = 25  # epoch成本约束
limit_tn = [83.59, 75.23, 67.71, 60.94, 54.84]  # 各epoch的TN最大值约束
limit_tp = [17.96, 16.17, 14.55, 13.10, 11.79]  # 各epoch的TP最大值约束
bankrate = 0.04  # 利率


"""建设、运行成本计算参数设置"""
# FS植被过滤带：建设成本+运行成本
filterstrip_unitccost = 983.32
filterstrip_unitmcost = 48.24
# GRSW植草沟：建设成本+运行成本
waterway_unitccost = 1320.00
waterway_unitmcost = 31.68
# TER梯田-建设成本(无运行成本)只有坡度大于5部分建设梯田
terracing_unitccost = 373.72
# MET养殖面源沼气池：建设成本+运行成本
animal_unitccost = 177.9
animal_unitmcost = 3.94
# USTE养殖污水处理厂提标改造：建设成本+运行成本
feedp_unitccost = 12.28
feedp_unitmcost = 1.87
# WET1污水处理厂湿地：建设成本+运行成本
border_unitccost = 959.61
border_unitmcost = 16.87
# WET2工厂湿地：建设成本+运行成本
factory_unitccost = 20.39
factory_unitmcost = 0.36
# FRTE测土施肥：运行成本
agrl_unitccost = 0
agrl_unitmcost = 65.12  # 827.8
# CHF农村生活+养殖面源：运行成本
rural_unitccost = 0
rural_unitmcost = 47.82


def cal_intervention_cost(solution):

    border = math.floor(solution.variables[0])
    factory = math.floor(solution.variables[1])
    feedp = math.floor(solution.variables[2])
    animal = math.floor(solution.variables[3])
    terracing = math.floor(solution.variables[4])
    filterstrip = math.floor(solution.variables[5])
    waterway = math.floor(solution.variables[6])
    agrla = math.floor(solution.variables[7])
    agrlb = math.floor(solution.variables[8])
    agrlc = math.floor(solution.variables[9])
    agrld = math.floor(solution.variables[10])
    agrle = math.floor(solution.variables[11])
    rurala = math.floor(solution.variables[12])
    ruralb = math.floor(solution.variables[13])
    ruralc = math.floor(solution.variables[14])
    rurald = math.floor(solution.variables[15])
    rurale = math.floor(solution.variables[16])

    """工程性措施相关"""
    # FS植被过滤带
    afil = np.mat(np.zeros((2, 5)))
    if filterstrip < 5:
        afil[0, filterstrip] = 1
        afil[1, filterstrip:] = 1
        filterstriplife = (5 - filterstrip) * 5
        filterstrip_ccost = filterstrip_unitccost * (1 + bankrate
                                                     ) ** filterstriplife
        filterstrip_mcost = filterstrip_unitmcost * sum(
            ((1 + bankrate) ** i for i in range(1, filterstriplife+1)))
    else:
        afil[:, :] = 0
        filterstrip_ccost = 0
        filterstrip_mcost = 0
    filterstrip_ccost_epo = 9.8332 * afil[0, :]
    filterstrip_mcost_epo = 2.412 * afil[1, :]
    filterstrip_cost_epo = filterstrip_ccost_epo + filterstrip_mcost_epo
    filterstrip_cost = filterstrip_ccost + filterstrip_mcost

    # GRSW植草沟:建设成本+运行成本
    bwat = np.mat(np.zeros((2, 5)))
    if waterway < 5:
        bwat[0, waterway] = 1
        bwat[1, waterway:] = 1
        waterwaylife = (5 - waterway) * 5
        waterway_ccost = waterway_unitccost * (1 + bankrate) ** waterwaylife
        waterway_mcost = waterway_unitmcost * sum(
            ((1 + bankrate) ** i for i in range(1, waterwaylife+1)))
    else:
        bwat[:, :] = 0
        waterway_ccost = 0
        waterway_mcost = 0
    waterway_ccost_epo = 13.2 * bwat[0, :]
    waterway_mcost_epo = 1.584 * bwat[1, :]
    waterway_cost_epo = waterway_ccost_epo + waterway_mcost_epo
    waterway_cost = waterway_ccost + waterway_mcost

    # TER梯田-建设成本(无运行成本)只有坡度大于5部分建设梯田
    cter = np.mat(np.zeros((2, 5)))
    if terracing < 5:
        cter[0, terracing] = 1
        cter[1, terracing:] = 1
        terracinglife = (5 - terracing) * 5
        terracing_cost = terracing_unitccost * (1 + bankrate) ** terracinglife
    else:
        cter[:, :] = 0
        terracing_cost = 0
    ter_cost_epo = 3.7372*cter[0, :]

    # MET养殖面源沼气池：建设成本+运行成本
    dani = np.mat(np.zeros((2, 5)))
    if animal < 5:
        dani[0, animal] = 1
        dani[1, animal:] = 1
        animallife = (5 - animal) * 5
        animal_ccost = animal_unitccost * (1 + bankrate) ** animallife
        animal_mcost = animal_unitmcost * sum(
            ((1 + bankrate) ** i for i in range(1, animallife+1)))
    else:
        dani[:, :] = 0
        animal_ccost = 0
        animal_mcost = 0
    animal_ccost_epo = 1.779*dani[0, :]
    animal_mcost_epo = 0.197*dani[1, :]
    animal_cost_epo = animal_ccost_epo + animal_mcost_epo
    animal_cost = animal_ccost + animal_mcost

    # USTE养殖污水处理厂提标改造：建设成本+运行成本
    efee = np.mat(np.zeros((2, 5)))
    if feedp < 5:
        efee[0, feedp] = 1
        efee[1, feedp:] = 1
        feedplife = (5 - feedp) * 5
        feedp_ccost = feedp_unitccost * (1 + bankrate) ** feedplife
        feedp_mcost = feedp_unitmcost * sum(
            ((1 + bankrate) ** i for i in range(1, feedplife+1)))
    else:
        efee[:, :] = 0
        feedp_ccost = 0
        feedp_mcost = 0
    feedp_ccost_epo = 0.1228 * efee[0, :]
    feedp_mcost_epo = 0.0935 * efee[1, :]
    feedp_cost_epo = feedp_ccost_epo + feedp_mcost_epo
    feedp_cost = feedp_ccost + feedp_mcost

    # WET1污水处理厂湿地：计算分epoch成本
    fbor = np.mat(np.zeros((2, 5)))
    if border < 5:
        fbor[0, border] = 1
        fbor[1, border:] = 1
        borderlife = (5 - border) * 5
        border_ccost = border_unitccost * (1 + bankrate) ** borderlife
        border_mcost = border_unitmcost * sum(
            ((1 + bankrate) ** i for i in range(1, borderlife+1)))
    else:
        fbor[:, :] = 0
        border_ccost = 0
        border_mcost = 0
    border_ccost_epo = 9.5961*fbor[0, :]
    border_mcost_epo = 0.8435*fbor[1, :]
    border_cost_epo = border_ccost_epo + border_mcost_epo
    border_cost = border_ccost + border_mcost

    # WET2污水处理厂工厂：计算分epoch成本
    gfac = np.mat(np.zeros((2, 5)))
    if factory < 5:
        gfac[0, factory] = 1
        gfac[1, factory:] = 1
        factorylife = (5 - factory) * 5
        factory_ccost = factory_unitccost * (1 + bankrate) ** factorylife
        factory_mcost = factory_unitmcost * sum(
            ((1 + bankrate) ** i for i in range(1, factorylife+1)))
    else:
        gfac[:, :] = 0
        factory_ccost = 0
        factory_mcost = 0
    factory_ccost_epo = 0.2039*gfac[0, :]
    factory_mcost_epo = 0.018*gfac[1, :]
    factory_cost_epo = factory_ccost_epo + factory_mcost_epo
    factory_cost = factory_ccost + factory_mcost

    """非工程性措施相关"""
    # FRTE测土施肥：运行成本
    hagrl = [agrla, agrlb, agrlc, agrld, agrle]
    hagrl = np.array((hagrl), dtype=float)
    agrl_cost_epo = 3.252 * hagrl
    agrla_cost = agrl_unitmcost * agrla * sum(((1 + bankrate) ** i for i in range(21, 26)))
    agrlb_cost = agrl_unitmcost * agrlb * sum(((1 + bankrate) ** i for i in range(16, 21)))
    agrlc_cost = agrl_unitmcost * agrlc * sum(((1 + bankrate) ** i for i in range(11, 16)))
    agrld_cost = agrl_unitmcost * agrld * sum(((1 + bankrate) ** i for i in range(6, 11)))
    agrle_cost = agrl_unitmcost * agrle * sum(((1 + bankrate) ** i for i in range(1, 6)))
    agrl_cost = agrla_cost + agrlb_cost + agrlc_cost + agrld_cost + agrle_cost
    # CHF农村生活+养殖面源：运行成本
    irural = [rurala, ruralb, ruralc, rurald, rurale]
    irural = np.array((irural), dtype=float)
    rural_cost_epo = 2.391 * irural
    rurala_cost = rural_unitmcost * rurala * sum(((1 + bankrate) ** i for i in range(21, 26)))
    ruralb_cost = rural_unitmcost * ruralb * sum(((1 + bankrate) ** i for i in range(16, 21)))
    ruralc_cost = rural_unitmcost * ruralc * sum(((1 + bankrate) ** i for i in range(11, 16)))
    rurald_cost = rural_unitmcost * rurald * sum(((1 + bankrate) ** i for i in range(6, 11)))
    rurale_cost = rural_unitmcost * rurale * sum(((1 + bankrate) ** i for i in range(1, 6)))               
    rural_cost = rurala_cost + ruralb_cost + ruralc_cost + rurald_cost + rurale_cost
    
    """总计"""
    solution.cost = filterstrip_cost + waterway_cost + terracing_cost + animal_cost + feedp_cost + border_cost + factory_cost + agrl_cost + rural_cost
    solution.cost_epo = filterstrip_cost_epo + waterway_cost_epo + ter_cost_epo + animal_cost_epo + feedp_cost_epo + border_cost_epo + factory_cost_epo + agrl_cost_epo + rural_cost_epo

    solution.cost_epoch_violation = 0
    for i in range(5):
        solution.cost_epoch_violation += max(0, solution.cost_epo[0, i]
                                             - limit_cost_epoch)

    return solution



def init_evaluation_fun(solution):

    solution = cal_intervention_cost(solution)
    solution.init_constraint_violation = solution.cost_epoch_violation
    return solution

